from keras import backend as K


def time_distributed_densenew(x, w, b=None, dropout=None,
                        input_dim=None, output_dim=None,
                        timesteps=None, training=None):
"""Apply `y . w + b` for every temporal slice y of x.
# Arguments
    x: input tensor.
    w: weight matrix.
    b: optional bias vector.
    dropout: wether to apply dropout (same dropout mask
        for every temporal slice of the input).
    input_dim: integer; optional dimensionality of the input.
    output_dim: integer; optional dimensionality of the output.
    timesteps: integer; optional number of timesteps.
    training: training phase tensor or boolean.
# Returns
    Output tensor.
"""
if not input_dim:
    input_dim = K.shape(x)[2]
if not timesteps:
    timesteps = K.shape(x)[1]
if not output_dim:
    output_dim = K.shape(w)[1]

if dropout is not None and 0. < dropout < 1.:
    # apply the same dropout pattern at every timestep
    ones = K.ones_like(K.reshape(x[:, 0, :], (-1, input_dim)))
    dropout_matrix = K.dropout(ones, dropout)
    expanded_dropout_matrix = K.repeat(dropout_matrix, timesteps)
    x = K.in_train_phase(x * expanded_dropout_matrix, x, training=training)

# collapse time dimension and batch dimension together
x = K.reshape(x, (-1, input_dim))
x = K.dot(x, w)
if b is not None:
    x = K.bias_add(x, b)
# reshape to 3D tensor
if K.backend() == 'tensorflow':
    x = K.reshape(x, K.stack([-1, timesteps, output_dim]))
    x.set_shape([None, None, output_dim])
else:
    x = K.reshape(x, (-1, timesteps, output_dim))
return x